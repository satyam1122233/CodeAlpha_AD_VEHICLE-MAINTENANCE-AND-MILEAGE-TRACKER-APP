package com.satyam.vehiclemaintenanceandmileagetrackerapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerServiceAdapter extends RecyclerView.Adapter<RecyclerServiceAdapter.ViewHolder> {
    Context context;
    ArrayList<ModelAddService> arrayList=new ArrayList<>();
    String id;
    RecyclerServiceAdapter(Context context, ArrayList<ModelAddService>arrayList){
        this.context=context;
        this.arrayList=arrayList;
    }

    @NonNull
    @Override
    public RecyclerServiceAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(context).inflate(R.layout.modellayout,parent,false);
        ViewHolder viewHolder =new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerServiceAdapter.ViewHolder holder, int position) {

        ModelAddService currentService = arrayList.get(position);


        holder.dateTxt.setText(arrayList.get(position).editTextTime);
        holder.odometerTxt.setText(arrayList.get(position).editTextOdometer);
        holder.serviceTxt.setText(arrayList.get(position).editTextServices);
        holder.costTxt.setText(arrayList.get(position).editTextCost);
        holder.serviceCentreTxt.setText(arrayList.get(position).editTextServiceCentre);

        holder.imageView.setImageResource(arrayList.get(position).img);
        id=arrayList.get(position).id;

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, SetContentActivity.class);

                // Put the service text as an extra in the Intent
                if (arrayList.get(position).img == R.drawable.dollarsymbol) {
                    id = "expenses";
                } else {
                    id = "service";
                }

                intent.putExtra("id", id);

                intent.putExtra("dateTxt", currentService.editTextTime);
                intent.putExtra("odometerTxt", currentService.editTextOdometer);
                intent.putExtra("serviceTxt", currentService.editTextServices);
                intent.putExtra("costTxt", currentService.editTextCost);
                intent.putExtra("serviceCentreTxt", currentService.editTextServiceCentre);

                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateTxt,costTxt,odometerTxt,serviceTxt,serviceCentreTxt;

        CardView cardView;
        ImageView imageView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            dateTxt=itemView.findViewById(R.id.dateTxt);
            costTxt=itemView.findViewById(R.id.costTxt);
            odometerTxt=itemView.findViewById(R.id.odometerTxt);
            serviceTxt=itemView.findViewById(R.id.serviceTxt);
            serviceCentreTxt=itemView.findViewById(R.id.serviceCentre);
            cardView=itemView.findViewById(R.id.cardView);

            imageView=itemView.findViewById(R.id.imageView);
        }
    }
}


package com.satyam.vehiclemaintenanceandmileagetrackerapplication;

public class ModelAddService {
    String editTextTime,editTextOdometer,editTextServices,editTextCost,editTextServiceCentre,id;

    int img;
    public ModelAddService(String id,String editTextTime, String editTextOdometer,
                           String editTextServices, String editTextCost,String editTextServiceCentre,int img) {
        this.id=id;
        this.editTextTime = editTextTime;
        this.editTextOdometer = editTextOdometer;
        this.editTextServices = editTextServices;
        this.editTextCost = editTextCost;
        this.editTextServiceCentre = editTextServiceCentre;

        this.img=img;
    }

}

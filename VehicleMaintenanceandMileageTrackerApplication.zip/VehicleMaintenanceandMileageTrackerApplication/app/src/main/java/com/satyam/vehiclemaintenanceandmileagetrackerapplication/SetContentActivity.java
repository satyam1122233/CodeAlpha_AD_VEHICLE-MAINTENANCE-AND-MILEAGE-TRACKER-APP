package com.satyam.vehiclemaintenanceandmileagetrackerapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SetContentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_content);

        TextView date,odometer,services,serviceCentre,cost,txt1,txt2;

        String id=getIntent().getStringExtra("id");
        String dateTxt=  getIntent().getStringExtra("dateTxt");
        String odometerTxt=  getIntent().getStringExtra("odometerTxt");
        String serviceTxt=  getIntent().getStringExtra("serviceTxt");
        String costTxt=  getIntent().getStringExtra("costTxt");
        String serviceCentreTxt=  getIntent().getStringExtra("serviceCentreTxt");


        txt1=findViewById(R.id.txt1);
        txt2=findViewById(R.id.txt2);

        date=findViewById(R.id.date);
        odometer=findViewById(R.id.odometer);
        services=findViewById(R.id.services);
        serviceCentre=findViewById(R.id.serviceCentre);
        cost=findViewById(R.id.cost);
        if (id.equals("expenses")){


            txt1.setText("Expenses");
            txt2.setText("Vendor");

            date.setText(dateTxt);
            odometer.setText(odometerTxt);
            services.setText(serviceTxt);
            serviceCentre.setText(serviceCentreTxt);
            cost.setText(costTxt);
        }else if(id.equals("service")){
            txt1.setText("Services");
            txt2.setText("Service Centre");


            date.setText(dateTxt);
            odometer.setText(odometerTxt);
            services.setText(serviceTxt);
            serviceCentre.setText(serviceCentreTxt);
            cost.setText(costTxt);

        }




    }
}
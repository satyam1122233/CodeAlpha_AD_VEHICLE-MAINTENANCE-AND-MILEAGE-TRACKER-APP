package com.satyam.vehiclemaintenanceandmileagetrackerapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        Button serviceBtn,vehicleInfoBtn;


            serviceBtn = findViewById(R.id.serviceBtn);
            vehicleInfoBtn = findViewById(R.id.vehicleInfoBtn);

            serviceBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(MainActivity.this,ServiceDetailes.class);
                    startActivity(intent);

                }
            });


            vehicleInfoBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });


        }




    }

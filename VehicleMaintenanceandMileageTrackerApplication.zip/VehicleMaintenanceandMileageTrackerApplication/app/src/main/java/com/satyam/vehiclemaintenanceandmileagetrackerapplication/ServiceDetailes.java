package com.satyam.vehiclemaintenanceandmileagetrackerapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.satyam.vehiclemaintenanceandmileagetrackerapplication.ModelAddService;
import com.satyam.vehiclemaintenanceandmileagetrackerapplication.R;
import com.satyam.vehiclemaintenanceandmileagetrackerapplication.RecyclerServiceAdapter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class ServiceDetailes extends AppCompatActivity  {
    RecyclerView recyclerView;
    FloatingActionButton floatingButton,addExpenses,addService;
    LinearLayout floatingElementsContainer;

    ArrayList<ModelAddService>arrayList = new ArrayList<>();

    RecyclerServiceAdapter adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_detailes);

        recyclerView=findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        floatingButton = findViewById(R.id.floatingButton);


        floatingElementsContainer = findViewById(R.id.floatingElementsContainer);

        addExpenses = findViewById(R.id.addExpenses);
        addService = findViewById(R.id.addService);


        floatingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toggle the visibility of the floating elements container
                if (floatingElementsContainer.getVisibility() == View.VISIBLE) {
                    floatingElementsContainer.setVisibility(View.GONE);

                } else {
                    floatingElementsContainer.setVisibility(View.VISIBLE);

                }



            }

        });


        addService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Dialog dialog=new Dialog(ServiceDetailes.this,R.style.FullScreenDialogTheme);
                dialog.setContentView(R.layout.addservicedialog);

                EditText editTextTime = dialog.findViewById(R.id.editTextTime);
                EditText editTextOdometer = dialog.findViewById(R.id.editTextOdometer);
                EditText editTextServices = dialog.findViewById(R.id.editTextServices);
                EditText editTextCost = dialog.findViewById(R.id.editTextCost);
                EditText editTextServiceCentre = dialog.findViewById(R.id.editTextServiceCentre);





                Button newTaskButton=dialog.findViewById(R.id.btnSave);
                Button btnCalander=dialog.findViewById(R.id.btnCalander);



                adapter = new RecyclerServiceAdapter(ServiceDetailes.this, arrayList);
                recyclerView.setAdapter(adapter); // Set the adapter to the RecyclerView

                newTaskButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String time="",odometer="",service="",cost="",serviceCentre="",id="service";


                        if (!editTextServiceCentre.getText().toString().equals("")){
                            time=editTextTime.getText().toString();
                            odometer=editTextOdometer.getText().toString();
                            service=editTextServices.getText().toString();
                            cost=editTextCost.getText().toString();

                            serviceCentre=editTextServiceCentre.getText().toString();

                            arrayList.add(new ModelAddService(id,time,odometer,service,cost,serviceCentre,R.drawable.wrench));

                            adapter.notifyItemInserted(arrayList.size() - 1);
                            recyclerView.scrollToPosition(arrayList.size() - 1);

                            dialog.dismiss();
                        }else{
                            Toast.makeText(ServiceDetailes.this, "Please Enter Service Centre Name", Toast.LENGTH_SHORT).show();
                        }


                    }




                });


                btnCalander.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showDatePickerDialog();
                    }

                    private void showDatePickerDialog() {
                        final Calendar c = Calendar.getInstance();
                        int year = c.get(Calendar.YEAR);
                        int month = c.get(Calendar.MONTH);
                        int day = c.get(Calendar.DAY_OF_MONTH);

                        DatePickerDialog datePickerDialog = new DatePickerDialog(
                                ServiceDetailes.this,
                                (view, selectedYear, selectedMonth, selectedDay) -> {
                                    String selectedDate = formatDate(selectedYear, selectedMonth, selectedDay);
                                    editTextTime.setText(selectedDate);
                                },
                                year,
                                month,
                                day
                        );
                        datePickerDialog.show();
                    }




                    private String formatDate(int year, int month, int day) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(year, month, day);
                        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
                        return dateFormat.format(calendar.getTime());
                    }
                });

                dialog.show();
            }



        });

        addExpenses.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {


                    Dialog dialog=new Dialog(ServiceDetailes.this,R.style.FullScreenDialogTheme);
                    dialog.setContentView(R.layout.addservicedialog);

                    EditText editTextTime = dialog.findViewById(R.id.editTextTime);
                    EditText editTextOdometer = dialog.findViewById(R.id.editTextOdometer);
                    EditText editTextServices = dialog.findViewById(R.id.editTextServices);
                    EditText editTextCost = dialog.findViewById(R.id.editTextCost);
                    EditText editTextServiceCentre = dialog.findViewById(R.id.editTextServiceCentre);



                    editTextServices.setHint("Expenses");
                        editTextServiceCentre.setHint("Vendor");


                    Button newTaskButton=dialog.findViewById(R.id.btnSave);
                    Button btnCalander=dialog.findViewById(R.id.btnCalander);



                    adapter = new RecyclerServiceAdapter(ServiceDetailes.this, arrayList);
                    recyclerView.setAdapter(adapter); // Set the adapter to the RecyclerView

                    newTaskButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String time="",odometer="",service="",cost="",serviceCentre="",id="expenses";


                            if (!editTextServices.getText().toString().equals("")){
                                time=editTextTime.getText().toString();
                                odometer=editTextOdometer.getText().toString();
                                service=editTextServices.getText().toString();
                                cost=editTextCost.getText().toString();

                                serviceCentre=editTextServiceCentre.getText().toString();

                                arrayList.add(new ModelAddService(id,time,odometer,service,cost,serviceCentre,R.drawable.dollarsymbol));

                                adapter.notifyItemInserted(arrayList.size() - 1);
                                recyclerView.scrollToPosition(arrayList.size() - 1);

                                dialog.dismiss();
                            }else{
                                Toast.makeText(ServiceDetailes.this, "Please Enter Expenses", Toast.LENGTH_SHORT).show();
                            }


                        }




                    });


                    btnCalander.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            showDatePickerDialog();
                        }

                        private void showDatePickerDialog() {
                            final Calendar c = Calendar.getInstance();
                            int year = c.get(Calendar.YEAR);
                            int month = c.get(Calendar.MONTH);
                            int day = c.get(Calendar.DAY_OF_MONTH);

                            DatePickerDialog datePickerDialog = new DatePickerDialog(
                                    ServiceDetailes.this,
                                    (view, selectedYear, selectedMonth, selectedDay) -> {
                                        String selectedDate = formatDate(selectedYear, selectedMonth, selectedDay);
                                        editTextTime.setText(selectedDate);
                                    },
                                    year,
                                    month,
                                    day
                            );
                            datePickerDialog.show();
                        }




                        private String formatDate(int year, int month, int day) {
                            Calendar calendar = Calendar.getInstance();
                            calendar.set(year, month, day);
                            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
                            return dateFormat.format(calendar.getTime());
                        }
                    });

                    dialog.show();





            }
        });







    }




}